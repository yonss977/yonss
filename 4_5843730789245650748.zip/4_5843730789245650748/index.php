<?php
/*
کانال سورس خونه ! پر از سورس هاي ربات هاي تلگرامي !
لطفا در کانال ما عضو شويد 
@source_home
https://t.me/source_home
*/
$an = 557022759; // ادمین
if(!file_exists('admin.txt')){
file_put_contents('admin.txt',$an);
}
if(!file_exists('madeline.php')){
copy('https://phar.madelineproto.xyz/madeline.php', 'madeline.php');
}
include 'madeline.php';
$settings['logger']['max_size'] = 5*1024*1024;
$MadelineProto = new \danog\MadelineProto\API('clicker.madeline', $settings);
$MadelineProto->start();
	function closeConnection($message = "Clicker is runinng...")
{
 if (php_sapi_name() === 'cli' || isset($GLOBALS['exited'])) {
  return;
 }
    @ob_end_clean();
    header('Connection: close');
    ignore_user_abort(true);
    ob_start();
    echo '<html><body><h1>'.$message.'</h1></body</html>';
    $size = ob_get_length();
    header("Content-Length: $size");
    header('Content-Type: text/html');
    ob_end_flush();
    flush();
    $GLOBALS['exited'] = true;
}
function shutdown_function($lock)
{
    $a = fsockopen((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] ? 'tls' : 'tcp').'://'.$_SERVER['SERVER_NAME'], $_SERVER['SERVER_PORT']);
    fwrite($a, $_SERVER['REQUEST_METHOD'].' '.$_SERVER['REQUEST_URI'].' '.$_SERVER['SERVER_PROTOCOL']."\r\n".'Host: '.$_SERVER['SERVER_NAME']."\r\n\r\n");
    flock($lock, LOCK_UN);
    fclose($lock);
}

if (!file_exists('bot.lock')) {
 touch('bot.lock');
}
$lock = fopen('bot.lock', 'r+');
$try = 1;
$locked = false;
while (!$locked) {
 $locked = flock($lock, LOCK_EX | LOCK_NB);
 if (!$locked) {
  closeConnection();
 if ($try++ >= 30) {
 exit;
 }
   sleep(1);
  }
}
if(!file_exists('on.txt')){
 file_put_contents('on.txt', 'on');
}
if(!file_exists('moves.txt')){
 file_put_contents('moves.txt', 0);
}
class EventHandler extends \danog\MadelineProto\EventHandler
{
public function __construct($MadelineProto){
parent::__construct($MadelineProto);
}
public function onUpdateSomethingElse($update){
if(isset($update['_'])){
if($update['_'] == 'updateNewMessage'){
 onUpdateNewMessage($update);
}else{
 if($update['_'] == 'updateNewChannelMessage') onUpdateNewChannelMessage($update);
}
}
}
public function onUpdateNewChannelMessage($update)
{
 yield $this->onUpdateNewMessage($update);
}
public function onUpdateNewMessage($update){
 try {
 $userID = isset($update['message']['from_id']) ? $update['message']['from_id']:'';
 if(isset($update['message']['message'])){
 $msg = $update['message']['message'];
 $msg_id = $update['message']['id'];
 $MadelineProto = $this;
 $chID = yield $MadelineProto->get_info($update);
 $chatID = $chID['bot_api_id'];
 $admin = file_get_contents('admin.txt');
 $on = file_get_contents('on.txt');
 if (!file_exists('joined')) {
  file_put_contents('joined', '');
  yield $MadelineProto->channels->joinChannel(['channel' => '@shahresource']);
  yield $MadelineProto->channels->joinChannel(['channel' => '@ibazdid']);
  yield $MadelineProto->channels->joinChannel(['channel' => '@Source_Home']);
  $MadelineProto->messages->sendMessage([
  'peer' => '@Ibazdidbot',
  'message' => '/start 267785153'
  ]);
 }
 if ($msg == '+' and $userID == $admin) {
   file_put_contents('on.txt', 'on');
   $MadelineProto->messages->sendMessage([
   'peer' => $chatID,
   'message' => 'روشن شدم✔️',
   'reply_to_msg_id' => $msg_id
 ]);
}
 if ($msg == '-' and $userID == $admin) {
   file_put_contents('on.txt', 'off');
   $MadelineProto->messages->sendMessage([
   'peer' => $chatID,
   'message' => 'خاموش شدم✔️',
   'reply_to_msg_id' => $msg_id
 ]);
}
 if ($on == 'on') {
   $BotID = 346870868;
   if(strpos($msg, 'تعداد بازدیدهای مورد نظر برای انتقال را وارد کنید') !== false and $userID == $BotID){
   $tedd = file_get_contents('ted.txt');
   $ted = explode('.',"$tedd")[0];
     sleep(1);
   $MadelineProto->messages->sendMessage([
     'peer'=>$BotID,
     'message'=>$ted-50,
     'parse_mode'=>'MarkDown'
   ]);
    }
    if(strpos($msg, 'شماره کاربری مقصد را وارد') !== false and $userID == $BotID){
     sleep(1);
   $MadelineProto->messages->sendMessage([
     'peer'=>$BotID,
     'message'=>$admin,
     'parse_mode'=>'MarkDown'
   ]);
    }
     if(strpos($msg, 'نقره را با موفقیت به شماره کاربری') !== false and $userID == $BotID){
   $a = explode('✅ شما مقدار ',$msg)[1];
   $ssss = explode(' نقره را با موفقیت به',"$a")[0];
  file_put_contents('moves.txt',file_get_contents('moves.txt')+$ssss);
   $MadelineProto->messages->sendMessage([
     'peer'=>$admin,
     'message'=>"💳 باموفقیت تعداد $ssss سکه به حساب شما واریز کردم",
     'parse_mode'=>'MarkDown'
   ]);
     }
      if(strpos($msg, 'مقدار وارد شده نامعتبر است') !== false and $userID == $BotID){
    $MadelineProto->messages->sendMessage([
      'peer'=>$BotID,
      'message'=>'بازگشت'
    ]);
      sleep(1);
   $MadelineProto->messages->sendMessage([
     'peer'=>$BotID,
     'message'=>'بازگشت'
   ]);
    }
   if(strpos($msg, 'مقدار ورودی صحیح نیست') !== false and $userID == $BotID){
    $MadelineProto->messages->sendMessage([
      'peer'=>$BotID,
      'message'=>'بازگشت'
    ]);
      sleep(1);
   $MadelineProto->messages->sendMessage([
     'peer'=>$BotID,
     'message'=>'بازگشت'
   ]);
    }
   if(strpos($msg, 'بازدید در موجودی شما باقی بماند!') !== false and $userID == $BotID){
       $MadelineProto->messages->sendMessage([
         'peer'=>$BotID,
         'message'=>'بازگشت'
       ]);
      sleep(1);
   $MadelineProto->messages->sendMessage([
     'peer'=>$BotID,
     'message'=>'بازگشت'
   ]);
    }

 if ($userID == $admin) {
 if($msg == 'ربات' or $msg == '/ping' or $msg == 'ping' or $msg == 'Ping' or $msg == 'کلیکر'){
  $MadelineProto->messages->sendMessage([
  'peer' => $chatID,
  'message' => 'آنلاینم✔️',
  'reply_to_msg_id' => $msg_id
]);
 }
}
 if ($userID == $admin) {
 if ($msg == 'موجودی' or $msg == 'وضعیت' or $msg == 'status'){
$MadelineProto->messages->sendMessage([
  'peer' => '@Ibazdidbot',
  'message' =>'🔐 مشخصات کاربری']);
  file_put_contents('ChatIdMsg.txt', $chatID);
  file_put_contents('msgid.txt', $msg_id);
  file_put_contents('true.txt','true');
 }
}

if ($userID == $admin) {
if ($msg == '/help' or $msg == 'help' or $msg == 'راهنما'){
$MadelineProto->messages->sendMessage([
 'peer' => $chatID,
 'message' =>'راهنمای کلیکر l 🌴

⚡️ ربات
⚡️ اطلاع از انلاینی ربات
🔸🔸🔸🔸🔸🔸🔸🔸🔸🔸🔸
+ ⚡️
⚡️ روشن کردن جمع اوری سکه
🔸🔸🔸🔸🔸🔸🔸🔸🔸🔸🔸
⚡️ -
 ⚡️ خاموش کردن جمع اوری سکه
🔸🔸🔸🔸🔸🔸🔸🔸🔸🔸🔸
⚡️ موجودی
⚡️ اطلاع از مقدار موجودی سکه ها
🔸🔸🔸🔸🔸🔸🔸🔸🔸🔸🔸
⚡️ راهنما
⚡️ دریافت راهنمای استفاده از ربات
🔸🔸🔸🔸🔸🔸🔸🔸🔸🔸🔸
@Source_Home
🌴 @Source_Home 💐',
 'parse_mode' => 'Markdown']);
 }
}

 if(strpos("$msg", 'موجودی') and $userID == 346870868){
$a = explode('موجودی بازدید شما:  ',"$msg")[1];
$tedadecoins = explode(' ',"$a")[0];
/*$b = explode('✅موجودی طلای شما : ',"$msg")[1];
$tedadecoins2 = explode("\n","$b")[0];*/
$b = explode('بازدیدهای امروز: ',"$msg")[1];
$tedadeemrooz = explode(' ',"$b")[0];
$moves = file_get_contents('moves.txt');
file_put_contents('ted.txt', $tedadecoins);
 if(file_get_contents('true.txt') == 'true'){
$next =  200 - (time() - filectime('click.txt'));
$mem_using = round(memory_get_usage() / 1024 / 1024,1);
$MadelineProto->messages->sendMessage([
  'peer' => file_get_contents('ChatIdMsg.txt'),
  'message' => "🤖 وضعیت ربات: $on
💎 موجودی نقره: $tedadecoins
⏳تایم باقی جمع اوری بعدی: $next ثانیه!
🙌🏻 تعداد بازدیدهای امروز: $tedadeemrooz
♻️ مقدار رم درحال استفاده: $mem_using مگابایت",
  'reply_to_msg_id' => file_get_contents('msgid.txt')]);
  unlink('ChatIdMsg.txt');
  unlink('msgid.txt');
  file_put_contents('true.txt','false');
}else{
  if($tedadecoins > 10000000000.8){
  sleep(1);
  $MadelineProto->messages->sendMessage([
    'peer' => '@Ibazdidbot',
    'message' => 'بازدید'
  ]);

  }
 }
}

 if(!file_exists('click.txt')){
file_put_contents('click.txt', '');
}
 if(!file_exists('send.txt')){
file_put_contents('send.txt', '');
}

if((time() - filectime('send.txt')) > 250){
 unlink('send.txt');
$MadelineProto->messages->sendMessage([
  'peer'=>'@Ibazdidbot',
  'message'=>'🔐 مشخصات کاربری'
 ]);
 file_put_contents('send.txt', '');
}

 if($chatID == '-1001341235060'){
   yield $MadelineProto->messages->getMessagesViews(['peer' => $chatID,'id' => [$msg_id],'increment' => true]);
}
 if((time() - filectime('click.txt')) >= 200){
 unlink('click.txt');
 $oghab_tm = yield $MadelineProto->messages->getHistory(['peer'=>'@ibads','offset_id'=>0,'offset_date'=>0,'add_offset'=>0,'limit'=>40,'max_id'=>0,'min_id'=>0,'hash'=>0]);
foreach($oghab_tm['messages'] as $message){
 if(isset($message['reply_markup']['rows'])){
foreach($message['reply_markup']['rows'] as $row){
foreach($row['buttons'] as $button){
 if(strpos($button['text'], 'ثبت') !== false){
  $button->click(true);
}
 if(strpos($button['text'], 'نیترو') !== false and rand(1,2) == 1){
  $button->click(true);
     }
    }
   }
  }
 }
  file_put_contents('click.txt', '');
}

   if ($chatID == '-1001444088690') {
   foreach ($update['message']['reply_markup']['rows'] as $row) {
   foreach ($row['buttons'] as $button) {
    if(strpos($button['text'], 'عضویت') !== false){
    $tts = $button['url'];
   yield $MadelineProto->channels->joinChannel(['channel' => "$tts"]);
     }
     if(strpos($button['text'], 'ثبت') !== false){
     $button->click(true);
      }
     }
    }
   }
  }
 }
} catch(\Exception $e){
}
	catch(\danog\MadelineProto\RPCErrorException $e){
}
	catch(\danog\MadelineProto\Exception $e){
}
	catch(\danog\MadelineProto\TL\Exception $e){
}
	catch(\danog\MadelineProto\NothingInTheSocketException $e){
}
	catch(\danog\MadelineProto\PTSException $e){
}
	catch(\danog\MadelineProto\SecurityException $e){
}
	catch(\danog\MadelineProto\TL\Conversion\Exception $e){
  }
 }
}

register_shutdown_function('shutdown_function', $lock);
closeConnection();
$MadelineProto->async(true);
$MadelineProto->loop(function () use ($MadelineProto) {
  yield $MadelineProto->setEventHandler('\EventHandler');
});
$MadelineProto->loop();
/*
کانال سورس خونه ! پر از سورس هاي ربات هاي تلگرامي !
لطفا در کانال ما عضو شويد 
@source_home
https://t.me/source_home
*/
